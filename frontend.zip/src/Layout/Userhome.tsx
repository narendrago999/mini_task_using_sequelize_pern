import React, { useEffect, useState } from 'react'
import Navigation from '../Components/navigation'
import Training from '../Components/Training'
import axios from 'axios'
import { useNavigate } from "react-router-dom"

const Userhome:React.FC = () => {
   
    const [userName, setuserName] = useState("")
    const Navigate = useNavigate()
    
    console.log(userName);
    useEffect(()=>{
            const token:string|null= sessionStorage.getItem("authToken")
            console.log("tokennnnnnn: ",token);
            async function getTraining(){
                const trainingData = await axios.get("http://localhost:8080/get-training-data",{headers:{Authorization:token}})
                setuserName(trainingData.data.userName);  
                // console.log("user :::", trainingData);
            }
           if(token!==null){
            getTraining()
           }else{
            sessionStorage.clear()
        Navigate('/')
           }
         
        
        })
  return (
   <>
    <div className="d-flex">
            <div className="cls">
                <Navigation name = {userName}/>
            </div>
            <div className="d-flex">
                <Training />
            </div>
        </div>
   </>
  )
}

export default Userhome