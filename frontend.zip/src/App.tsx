// import React from 'react';
// import logo from './logo.svg';
// import './App.css';
import Routing from './Services/Routing';

function App() {
  return (
    <Routing/>
  );
}

export default App;
