import { useState } from "react";
import "../Styles/form.css";

//React Bootstrap Modal
import TextField from "@mui/material/TextField";

// //For Date and Time Component
// import dayjs, { Dayjs } from 'dayjs';
// import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
// import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
// import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
// import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';

//For Select option element
import Box from "@mui/material/Box";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select, { SelectChangeEvent } from "@mui/material/Select";

import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import axios from "axios";
import Trial from "./trial";

const TrainingForm = () => {
  // const [modalShow, setModalShow] = useState(false);
  // const onHide = () => setModalShow(false)
  // const [age, setAge] = useState('');

  // const handleChange = (event: SelectChangeEvent) => {
  //     setAge(event.target.value as string);
  // };
  // const [value, setValue] = useState<Dayjs | null>(dayjs('2022-04-17T15:30'));

  const [trainingTitle, setTrainingTitle] = useState("");
  const [skillTitle, setSkillTitle] = useState("");
  const [skillCategory, setSkillCategory] = useState("");
  const [desc, setDesc] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  
const [limit, setLimit] = useState("");

  const data = {
    trainingTitle: trainingTitle,
    skillTitle: skillTitle,
    description: desc,
    skillCategory: skillCategory,
    startDateTime:startDate,
    endDateTime: endDate,
    limit: limit,
  };

  const [post, setPost] = useState(null);

  const createTraining = () => {
  
    if (
      trainingTitle.trim() !== "" ||
      skillTitle.trim() !== "" ||
      desc.trim() !== "" ||
      skillCategory.trim() !== ""
    ) {
      const url = `http://localhost:8080/admin`;
      axios
        .post(url, data)
        .then((response) => {
          setPost(response.data);
          if(response.data.message ==="Training Created Successfully"){
            toast.success("Training Created Successfully", {
              position: toast.POSITION.TOP_RIGHT,
            });
          }
          if(response.data.message ==="Training Already Exists"){
            toast.warning("Training Already Exists", {
              position: toast.POSITION.TOP_RIGHT,
            });
          }
        
        })
        .catch((error) => {
          toast.error("Network Error", {
            position: toast.POSITION.TOP_RIGHT,
          });
          console.log(error);
        });
    } else {
      toast.error("Update not Valid. Please check all the mandatory fields", {
        position: toast.POSITION.TOP_RIGHT,
      });
    }
  };
 
  return (
    <div className="d-flex justify-content-between main-training-box">
      {/* <div>
        <Trial/>
      </div> */}
      <h1 className="heading">Learning & Development</h1>
      {window.location.pathname==='/home'?
      <div>
        <button
          className="btn mybtn register"
          data-bs-toggle="modal"
          data-bs-target="#myModal"
        >
          + Create Training<i className="fas fa-arrow-right"></i>
        </button>

        <div className="modal" id="myModal">
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="pe-3 ps-3">
                <div className="modal-header">
                  <h1 className="modal-title heading">New Request</h1>

                  <button
                    type="button"
                    className="btn-close close-button"
                    data-bs-dismiss="modal"
                  ></button>
                </div>
                <div className="modal-body">
                  <p className="labels">
                    Training Title<span className="text-danger">*</span>
                  </p>
                  <TextField
                    fullWidth
                    required
                    id="trainingTitle"
                    size="small"
                    className="mb-2"
                    onChange={(e) => setTrainingTitle(e.target.value)}
                  />
                  <div className="d-flex flex-row mb-2">
                    <div className="me-2">
                      <p className="labels">
                        Skill Title<span className="text-danger">*</span>
                      </p>
                      <TextField
                        required
                        id="skillTitle"
                        size="small"
                        onChange={(e) => setSkillTitle(e.target.value)}
                      />
                    </div>
                    <div>
                      <p className="labels">
                        Skill Category<span className="text-danger">*</span>
                      </p>
                      <TextField
                        required
                        id="skillCategory"
                        size="small"
                        onChange={(e) => setSkillCategory(e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="dates d-flex justify-content-between mb-2">
                    <div>
                      <p className="labels">
                        Start Date<span className="text-danger">*</span>
                      </p>
                      <input type="date" id="startDate" name="startDate" className="date-input" onChange={(e) => setStartDate(e.target.value)}/>
                    </div>
                    <div>
                      <p className="labels">
                        End Date<span className="text-danger">*</span>
                      </p>
                      <input type="date" id="endDate" name="endDate"  className="date-input" onChange={(e) => setEndDate(e.target.value)}/>
                    </div>
                    <div>
                      <p className="labels">
                        Limit<span className="text-danger">*</span>
                      </p>
                      <input type="text-box" id="limit" name="limit" className="date-input" onChange={(e) => setLimit(e.target.value)}/>
                    </div>

                  </div>
                  <div className="description">
                    <p className="labels">
                      Description<span className="text-danger">*</span>
                    </p>
                    <textarea
                      className="form-control"
                      id="exampleFormControlTextarea1"
                      onChange={(e) => setDesc(e.target.value)}
                    ></textarea>
                  </div>
                </div>
                <div className="modal-footer d-flex justify-content-end">
                  <div>
                    <ToastContainer />
                    <button className="submit-button" onClick={createTraining}>
                      Submit
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>:''

    }
    </div> 

  );
};

export default TrainingForm;
