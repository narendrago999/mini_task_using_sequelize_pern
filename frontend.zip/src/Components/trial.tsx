const Trial = () => {
    return (
        <>
            <button className="btn mybtn" data-bs-toggle="modal"

                data-bs-target="#myModal">Request<i className='fas fa-arrow-right'></i></button>
            <div className="modal" id="myModal">

                <div className="modal-dialog">

                    <div className="modal-content">



                     
                        <div className="modal-header">

                            <h4 className="modal-title">New Request</h4>

                            <button type="button" className="btn-close" data-bs-dismiss="modal"></button>

                        </div>



                       

                        <div className="modal-body">

                            <form action="/action_page.php">

                                <div className="RT">

                                    <label htmlFor="requestType" className="form-label">Request Type <span

                                        className="text-danger">*</span></label>

                                    

                                </div>

                                <div className="row dates">

                                    <div className="col-sm-4 startdate">

                                        <label htmlFor="startDate" className="form-label">Start Date <span

                                            className="text-danger">*</span></label>

                                        <input type="date" className="form-control inp" id="startDate"

                                            placeholder="Start Date" name="startDate" required/>

                                    </div>

                                    <div className="col-sm-4 endDate">

                                        <label htmlFor="startDate" className="form-label">End Date <span

                                            className="text-danger">*</span></label>

                                        <input type="date" className="form-control inp" id="endDate"

                                            placeholder="End Date" name="endDate" required/>

                                    </div>

                                    <div className="col-sm-4 halfDay">

                                        <p> </p>

                                        <input type="checkbox" className="inp" id="halfDay" name="halfDay" required/>

                                            <label className="checkbox-label" htmlFor="halfDay">Half Day</label>

                                    </div>

                                </div>

                                <div className="textarea">

                                    <textarea className="inp" name="textarea" id="textarea" 

                                        placeholder="Discription"></textarea>

                                </div>

                                <p className="total-days">Total Days <span className="text-success">0</span></p>

                            </form>

                        </div>



                     

                        <div className="modal-footer f">

                            <div className="user">

                                <div>

                                    <img src="ben10.jpg" alt="profile pic" className="rounded-circle pro-pic"/>

                                </div>

                                <div>

                                    <h6>Sairam Tennyson</h6>

                                    <p>Project Manager</p>

                                </div>

                            </div>



                            <button type="submit" className="btn btn-danger" data-bs-dismiss="modal">Send

                                Request</button>

                        </div>



                    </div>

                </div>

            </div>
        </>
    )
}

export default Trial;