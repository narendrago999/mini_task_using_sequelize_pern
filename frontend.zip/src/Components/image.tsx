import '../Styles/image.css'

const Image = ()=>{
    return(
        <div className='image-container'>
                <h1 className='text-light'>JIN <span className='spanner'>Connected Apps</span></h1>
            </div>
    )
}
export default Image;