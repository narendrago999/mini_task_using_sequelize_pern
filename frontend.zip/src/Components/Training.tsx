import React, { useEffect, useState } from 'react'
import '../Styles/LandDScreen.css';
import Card from './card';
import TrainingForm from './Form';
import axios from 'axios';
import { useNavigate } from "react-router-dom";

const Training: React.FC = () => {
    const [tokendata, setTokendata] = useState('')
    const [trainingData, setTrainingData] = useState([])
    const Navigate = useNavigate()
    useEffect(() => {
        const token: string | null = sessionStorage.getItem("authToken")
        console.log("token>", token);
        async function getTraining() {
            const trainingData = await axios.get("http://localhost:8080/get-training-data", { headers: { Authorization: token } })
           if(trainingData.data.trainingData){
               setTrainingData(trainingData.data.trainingData)
           }
           if(trainingData.data.message==="Token Not Found"){
            Navigate('/')
           }
           if(trainingData.data.message==="TokenExpiredError"){
            Navigate('/')
           }
        }
        if (token !== null) {
            setTokendata(token)
            getTraining()
        } else {
            sessionStorage.clear()
            Navigate('/')
        }
    }, [])

    return (
        <>
            <div className="main-card">


                <div className='container-fluid'>
                    <TrainingForm />
                    <div className="trainingBox">


                        {trainingData.map(data =>
                            <div className="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12 p-3">
                                < Card tdata={data} />
                            </div>
                        )

                        }

                    </div>


                </div>
            </div>
        </>
    );
}

export default Training