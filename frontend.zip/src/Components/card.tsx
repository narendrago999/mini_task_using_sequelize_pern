import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";

export default function Card(props:any){
const Navigate = useNavigate()
const [tokendata, setTokendata] = useState('')
    useEffect(()=>{
        const token:string|null = sessionStorage.getItem("authToken")
        if(token !== null){
            setTokendata(token)
        }
    },[])
    

    async function handleTraining(){
        try {
            const trainingTitle =await props.tdata.trainingTitle
            const send = await axios.get(`http://localhost:8080/training-request/${trainingTitle}`,{headers:{Authorization:tokendata}})
            console.log(send.data.message);
            if(send.data.message==="already taken"){
                toast.warning("already Registered", {
                    position: toast.POSITION.TOP_RIGHT,
                  });
            }
            else if(send.data.message==="Limit Reached"){
                toast.error("Limit Reached", {
                    position: toast.POSITION.TOP_RIGHT,
                  });
            }
            else if(send.data.message==="success"){
                toast.success("success", {
                    position: toast.POSITION.TOP_RIGHT,
                  });
            }
            else if(send.data.message==="already exists"){
                toast.warning("Already Registered", {
                    position: toast.POSITION.TOP_RIGHT,
                  });
            }
            else if(send.data.message==="Training Success"){
                toast.success("Training Success", {
                    position: toast.POSITION.TOP_RIGHT,
                  });
            }
            else if(send.data.message==="Training Not Found"){
                toast.error("Training Not Found", {
                    position: toast.POSITION.TOP_RIGHT,
                  });
            }
            else if(send.data.message==="Token Not Found"){
                toast.error("Token Not Found", {
                    position: toast.POSITION.TOP_RIGHT,
                  });
            }
            else if(send.data.message==="TokenExpiredError"){
                toast.error("Session Expired", {
                    position: toast.POSITION.TOP_RIGHT,
                  });
                  Navigate('/')
            }
            
        } catch (error) {
            console.log(error);
            
        }
    }



    return (
        <div className="card">
            <div className="card-body">
                    <h5 className="card-title card-heading">{props.tdata.trainingTitle}</h5>
                <div className='card-body body-text'>
                    <h5><strong>Skills: </strong> {props.tdata.skillTitle}</h5>
                    <h6><strong>Skill Category: </strong> {props.tdata.skillCategory}</h6>
                    
                    <p className="card-text card-description">{props.tdata.description}</p>
                </div>
                <div className="foot">
                {window.location.pathname==='/userhome'?<button className='btn btn-sm see-more'  onClick={handleTraining}>Register</button>:''}
                </div>
                

            </div>
            <ToastContainer/>
        </div>
    );
}