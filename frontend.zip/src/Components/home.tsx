// import LandD from "./LandDScreen";
import Navigation from "./navigation";

import './home.css';
import Training from "./Training";

const Home = () => {

    return (

        <div className="d-flex">
            <div className="cls">
                <Navigation />
            </div>
            <div className="d-flex">
                <Training />
            </div>
        </div>

    )

}

export default Home